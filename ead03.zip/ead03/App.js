// src/screens/CadastroScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

const CadastroScreen = ({ navigation }) => {
  const [cpf, setCpf] = useState('');
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [isFormValid, setIsFormValid] = useState(false);

  // Valida se todos os campos estão preenchidos para habilitar o botão Salvar [cite: 7]
  useEffect(() => {
    if (cpf && nome && email && senha) {
      setIsFormValid(true);
    } else {
      setIsFormValid(false);
    }
  }, [cpf, nome, email, senha]);

  const handleSalvar = () => {
    // Exibe a mensagem de sucesso [cite: 9]
    Alert.alert('Sucesso', 'Usuário registrado com sucesso', [
      // Retorna para a tela de login [cite: 9]
      { text: 'OK', onPress: () => navigation.goBack() },
    ]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cadastro de Usuário</Text>
      
      {/* Campos de CPF, Nome, Email e Senha [cite: 6] */}
      <TextInput
        style={styles.input}
        placeholder="CPF"
        value={cpf}
        onChangeText={setCpf}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Nome Completo"
        value={nome}
        onChangeText={setNome}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />
      
      {/* Botão Salvar habilitado condicionalmente  */}
      <Button
        title="Salvar"
        onPress={handleSalvar}
        disabled={!isFormValid}
      />
      
      <View style={styles.buttonSpacer} />
      
      {/* Botão para retornar à tela de login  */}
      <Button
        title="Voltar para Login"
        onPress={() => navigation.goBack()}
        color="grey"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  input: { height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 12, paddingHorizontal: 8 },
  buttonSpacer: { height: 10 },
});

export default CadastroScreen;