import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  Button, 
  Image, 
  StyleSheet, 
  Alert, 
  Pressable 
} from 'react-native';

export default function App() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  // Usuário fictício para validação
  const validEmail = "teste@gmail.com";
  const validSenha = "123456";

  const handleLogin = () => {
    if (email === validEmail && senha === validSenha) {
      Alert.alert("Login realizado com sucesso!");
    } else {
      Alert.alert("E-mail ou senha inválidos!");
    }
  };

  const handleRegister = () => {
    Alert.alert("Tela de Registro em breve!");
  };

  const handleResetPassword = () => {
    Alert.alert("Tela de redefinição de senha em breve!");
  };

  return (
    <View style={styles.container}>
      <Image 
        source={{uri: 'https://reactnative.dev/img/tiny_logo.png'}} 
        style={styles.logo} 
      />

      <Text style={styles.label}>E-mail</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu e-mail"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />

      <Text style={styles.label}>Senha</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite sua senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      <Button 
        title="ENTRAR" 
        onPress={handleLogin} 
        disabled={!email || !senha}
      />

      <View style={styles.links}>
        <Pressable onPress={handleRegister}>
          <Text style={styles.linkText}>Registrar-se</Text>
        </Pressable>

        <Pressable onPress={handleResetPassword}>
          <Text style={styles.linkText}>Redefinir a Senha</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5'
  },
  logo: {
    width: 100,
    height: 100,
    alignSelf: 'center',
    marginBottom: 30
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fff'
  },
  links: {
    marginTop: 20,
    alignItems: 'center'
  },
  linkText: {
    color: 'blue',
    marginTop: 10,
    textDecorationLine: 'underline'
  }
});
