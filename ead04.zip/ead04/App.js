// app/_layout.js
import { Stack } from 'expo-router';
import React from 'react';

// Configura o layout de navegação principal do aplicativo
const RootLayout = () => {
  return (
    <Stack>
      {/* Define a tela inicial (Home) */}
      <Stack.Screen name="index" options={{ title: 'Home' }} />
      {/* Define a tela de perfil */}
      <Stack.Screen name="perfil" options={{ title: 'Perfil' }} />
    </Stack>
  );
};

export default RootLayout;